import apiClient from '../../api/client';

export const listUsers = () => apiClient.get('/users').then((r) => r.data.data);
export const createStaff = (payload) => apiClient.post('/users', payload).then((r) => r.data.data);
