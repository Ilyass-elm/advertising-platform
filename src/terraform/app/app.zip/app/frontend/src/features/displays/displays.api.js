import apiClient from '../../api/client';

export const listMyDisplays = () => apiClient.get('/displays/mine').then((r) => r.data.data);
export const listBrowsableDisplays = () => apiClient.get('/displays/browse').then((r) => r.data.data);
export const listAllDisplays = () => apiClient.get('/displays').then((r) => r.data.data);
export const createDisplay = (payload) => apiClient.post('/displays', payload).then((r) => r.data.data);
export const assignDisplay = (id, clientId) => apiClient.patch(`/displays/${id}/assign`, { clientId }).then((r) => r.data.data);
export const getDisplayNow = (id) => apiClient.get(`/displays/${id}/now`).then((r) => r.data.data);
