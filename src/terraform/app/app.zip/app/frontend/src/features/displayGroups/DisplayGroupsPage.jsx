import { useEffect, useState } from 'react';
import { listGroups, createGroup, addMembers } from './displayGroups.api';
import { listAllDisplays } from '../displays/displays.api';

export default function DisplayGroupsPage() {
  const [groups, setGroups] = useState([]);
  const [displays, setDisplays] = useState([]);
  const [name, setName] = useState('');

  const refresh = () => listGroups().then(setGroups);
  useEffect(() => { refresh(); listAllDisplays().then(setDisplays); }, []);

  async function handleCreate(e) {
    e.preventDefault();
    await createGroup({ name });
    setName('');
    refresh();
  }

  return (
    <div>
      <h2>Display Groups</h2>
      <form onSubmit={handleCreate} style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
        <input placeholder="Group name" value={name} onChange={(e) => setName(e.target.value)} required />
        <button type="submit">Create group</button>
      </form>
      {groups.map((g) => (
        <div key={g.id} style={{ border: '1px solid #ddd', padding: 12, marginBottom: 12 }}>
          <strong>{g.name}</strong> ({g.members.length} displays)
          <ul>{g.members.map((m) => <li key={m.id}>{m.name}</li>)}</ul>
          <select onChange={(e) => e.target.value && addMembers(g.id, [e.target.value]).then(refresh)} defaultValue="">
            <option value="" disabled>+ add display...</option>
            {displays.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
          </select>
        </div>
      ))}
    </div>
  );
}
