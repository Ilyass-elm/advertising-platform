import { useEffect, useState } from 'react';
import { listUsers, createStaff } from './users.api';

export default function UsersPage() {
  const [users, setUsers] = useState([]);
  const [form, setForm] = useState({ email: '', password: '', fullName: '', role: 'employee' });

  const refresh = () => listUsers().then(setUsers);
  useEffect(() => { refresh(); }, []);

  async function handleCreate(e) {
    e.preventDefault();
    await createStaff(form);
    setForm({ email: '', password: '', fullName: '', role: 'employee' });
    refresh();
  }

  return (
    <div>
      <h2>Users (admin only)</h2>
      <form onSubmit={handleCreate} style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
        <input placeholder="Full name" value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} required />
        <input placeholder="Email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} required />
        <input placeholder="Password" type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} required />
        <select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
          <option value="employee">employee</option>
          <option value="admin">admin</option>
        </select>
        <button type="submit">Create</button>
      </form>
      <table border="1" cellPadding="6" style={{ borderCollapse: 'collapse', width: '100%' }}>
        <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Active</th></tr></thead>
        <tbody>
          {users.map((u) => (
            <tr key={u.id}><td>{u.full_name}</td><td>{u.email}</td><td>{u.role}</td><td>{u.is_active ? 'yes' : 'no'}</td></tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
