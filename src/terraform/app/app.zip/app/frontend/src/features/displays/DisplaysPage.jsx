import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../auth/AuthContext';
import { listBrowsableDisplays, listAllDisplays, createDisplay, assignDisplay } from './displays.api';
import { listClients } from '../clients/clients.api';

// Admin adds a display (name + location), optionally assigns it to a client.
// Everyone (client and staff) can open a display to see what's running on it.
// Clients see every display on the platform, since they can target any of them.
export default function DisplaysPage() {
  const { user } = useAuth();
  const isClient = user.role === 'client';
  const [displays, setDisplays] = useState([]);
  const [clients, setClients] = useState([]);
  const [name, setName] = useState('');
  const [location, setLocation] = useState('');
  const [clientId, setClientId] = useState('');

  const refresh = () => (isClient ? listBrowsableDisplays() : listAllDisplays()).then(setDisplays);
  useEffect(() => {
    refresh();
    if (!isClient) listClients().then(setClients);
  }, []);

  async function handleCreate(e) {
    e.preventDefault();
    await createDisplay({ name, location, clientId: clientId || undefined });
    setName(''); setLocation(''); setClientId('');
    refresh();
  }

  async function handleAssign(displayId, newClientId) {
    await assignDisplay(displayId, newClientId || null);
    refresh();
  }

  return (
    <div>
      <h2>Displays</h2>

      {!isClient && (
        <form onSubmit={handleCreate} style={{ display: 'flex', gap: 8, marginBottom: 16, flexWrap: 'wrap' }}>
          <input placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} required />
          <input placeholder="Location" value={location} onChange={(e) => setLocation(e.target.value)} />
          <select value={clientId} onChange={(e) => setClientId(e.target.value)}>
            <option value="">(assign later)</option>
            {clients.map((c) => <option key={c.id} value={c.id}>{c.company_name}</option>)}
          </select>
          <button type="submit">Add display</button>
        </form>
      )}

      <table border="1" cellPadding="6" style={{ borderCollapse: 'collapse', width: '100%' }}>
        <thead>
          <tr>
            <th>Name</th><th>Location</th>
            {!isClient && <th>Client</th>}
            <th></th>
          </tr>
        </thead>
        <tbody>
          {displays.map((d) => (
            <tr key={d.id}>
              <td>{d.name}</td><td>{d.location}</td>
              {!isClient && (
                <td>
                  <select value={d.client_id || ''} onChange={(e) => handleAssign(d.id, e.target.value)}>
                    <option value="">(unassigned)</option>
                    {clients.map((c) => <option key={c.id} value={c.id}>{c.company_name}</option>)}
                  </select>
                </td>
              )}
              <td><Link to={`/displays/${d.id}`}>What's playing →</Link></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
