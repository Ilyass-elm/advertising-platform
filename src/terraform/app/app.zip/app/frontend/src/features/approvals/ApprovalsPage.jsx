import { useEffect, useState } from 'react';
import { getQueue, review } from './approvals.api';

export default function ApprovalsPage() {
  const [queue, setQueue] = useState([]);
  const [reasonDraft, setReasonDraft] = useState({});

  const refresh = () => getQueue().then(setQueue);
  useEffect(() => { refresh(); }, []);

  async function act(id, decision) {
    await review(id, decision, decision === 'rejected' ? (reasonDraft[id] || '') : undefined);
    refresh();
  }

  return (
    <div>
      <h2>Pending Approvals</h2>
      {queue.length === 0 && <p>Nothing pending.</p>}
      {queue.map((c) => (
        <div key={c.id} style={{ border: '1px solid #ddd', padding: 12, marginBottom: 12 }}>
          <strong>{c.name}</strong> — {c.company_name}<br />
          {c.start_date} → {c.end_date}, priority {c.priority}, {c.targets.length} target(s)
          <div style={{ marginTop: 8, display: 'flex', gap: 8, alignItems: 'center' }}>
            <button onClick={() => act(c.id, 'approved')}>Approve</button>
            <input placeholder="Rejection reason" value={reasonDraft[c.id] || ''}
              onChange={(e) => setReasonDraft({ ...reasonDraft, [c.id]: e.target.value })} />
            <button onClick={() => act(c.id, 'rejected')}>Reject</button>
          </div>
        </div>
      ))}
    </div>
  );
}
