import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useAuth } from '../../auth/AuthContext';
import { getDisplayNow } from './displays.api';
import CreativePreview from '../../components/CreativePreview';

function CampaignCard({ c, showCompany }) {
  return (
    <div style={{ border: '1px solid #ddd', padding: 12, marginBottom: 12 }}>
      <div>
        <Link to={`/campaigns/${c.id}`}><strong>{c.name}</strong></Link>
        {showCompany && <span style={{ color: '#666' }}> — {c.company_name}</span>}
        <span style={{ float: 'right', fontSize: 13 }}>priority {c.priority}</span>
      </div>
      <div style={{ fontSize: 13, color: '#666', margin: '4px 0 8px' }}>
        {c.start_date} → {c.end_date}, daily {c.time_start}-{c.time_end}
      </div>
      {c.reason && <div style={{ fontSize: 13, color: '#b45309', marginBottom: 8 }}>Not playing right now: {c.reason}</div>}
      <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
        {c.items.map((item, i) => (
          <div key={item.id} style={{ width: 120, fontSize: 12 }}>
            <CreativePreview
              advertisementId={item.advertisement_id}
              fileType={item.file_type}
              style={{ width: 120, height: 70, objectFit: 'contain', background: '#000', display: 'block' }}
            />
            <div>{i + 1}. {item.title}</div>
            <div style={{ color: '#666' }}>{item.duration_seconds}s</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// "What is running on this display" - for troubleshooting from both the
// client and admin panel. Derived from approved campaigns + their schedule
// (there is no device reporting back), auto-refreshes every 30s.
export default function DisplayNowPage() {
  const { id } = useParams();
  const { user } = useAuth();
  const isClient = user.role === 'client';
  const [data, setData] = useState(null);
  const [error, setError] = useState('');

  const load = () => getDisplayNow(id).then(setData).catch((e) => setError(e.response?.data?.error || 'Could not load display'));
  useEffect(() => {
    load();
    const timer = setInterval(load, 30000);
    return () => clearInterval(timer);
  }, [id]);

  if (error) return <p style={{ color: 'red' }}>{error}</p>;
  if (!data) return <p>Loading…</p>;

  return (
    <div>
      <p><Link to="/displays">← Back to displays</Link></p>
      <h2>{data.display.name}</h2>
      <p style={{ color: '#666' }}>
        {data.display.location || 'no location set'} · server time (UTC): {data.serverTime.slice(0, 16).replace('T', ' ')}{' '}
        <button onClick={load}>Refresh</button>
      </p>
      <p style={{ fontSize: 12, color: '#666' }}>
        Based on approved campaigns and their schedule — not a report from the screen itself.
        {isClient && ' You only see your own campaigns here.'} Highest priority first.
      </p>

      <h3>Playing now ({data.playing.length})</h3>
      {data.playing.length === 0 && <p>Nothing {isClient ? 'of yours ' : ''}is scheduled to play on this display right now.</p>}
      {data.playing.map((c) => <CampaignCard key={c.id} c={c} showCompany={!isClient} />)}

      <h3>Approved, but not playing right now ({data.waiting.length})</h3>
      {data.waiting.length === 0 && <p>None.</p>}
      {data.waiting.map((c) => <CampaignCard key={c.id} c={c} showCompany={!isClient} />)}
    </div>
  );
}
