import apiClient from '../../api/client';

export const getDashboard = () => apiClient.get('/dashboard').then((r) => r.data.data);
