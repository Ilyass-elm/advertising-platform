import apiClient from '../../api/client';

export const getQueue = () => apiClient.get('/approvals/queue').then((r) => r.data.data);
export const review = (campaignId, decision, rejectionReason) =>
  apiClient.post(`/approvals/${campaignId}/review`, { decision, rejectionReason }).then((r) => r.data.data);
