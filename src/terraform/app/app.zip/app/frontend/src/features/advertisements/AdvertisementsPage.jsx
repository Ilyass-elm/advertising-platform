import { useEffect, useState } from 'react';
import { listMyAds, uploadAd } from './advertisements.api';

// Duration is no longer set here - it's chosen per-campaign when a client
// builds their creative sequence (see CampaignForm), since the same
// creative can play for a different length in different campaigns.
export default function AdvertisementsPage() {
  const [ads, setAds] = useState([]);
  const [title, setTitle] = useState('');
  const [file, setFile] = useState(null);
  const [error, setError] = useState('');

  const refresh = () => listMyAds().then(setAds);
  useEffect(() => { refresh(); }, []);

  async function handleUpload(e) {
    e.preventDefault();
    setError('');
    if (!file) return setError('Choose a file first');
    try {
      await uploadAd(file, title);
      setTitle(''); setFile(null);
      refresh();
    } catch (err) {
      setError(err.response?.data?.error || 'Upload failed');
    }
  }

  return (
    <div>
      <h2>My Advertisements</h2>
      <p style={{ fontSize: 13, color: '#666' }}>
        Upload as many creatives as you like — you'll pick the play order and
        duration for each when you build a campaign.
      </p>
      <form onSubmit={handleUpload} style={{ marginBottom: 24, display: 'flex', gap: 8, alignItems: 'center' }}>
        <input placeholder="Title" value={title} onChange={(e) => setTitle(e.target.value)} required />
        <input type="file" accept="image/*,video/mp4,video/webm" onChange={(e) => setFile(e.target.files[0])} required />
        <button type="submit">Upload</button>
      </form>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <table border="1" cellPadding="6" style={{ borderCollapse: 'collapse', width: '100%' }}>
        <thead><tr><th>Title</th><th>Type</th><th>Uploaded</th></tr></thead>
        <tbody>
          {ads.map((a) => (
            <tr key={a.id}>
              <td>{a.title}</td><td>{a.file_type}</td><td>{a.uploaded_at}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
