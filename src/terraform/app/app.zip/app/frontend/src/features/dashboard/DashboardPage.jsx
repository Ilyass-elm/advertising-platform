import { useEffect, useState } from 'react';
import { getDashboard } from './dashboard.api';

export default function DashboardPage() {
  const [data, setData] = useState(null);

  useEffect(() => { getDashboard().then(setData); }, []);

  if (!data) return <p>Loading...</p>;

  if (data.role === 'client') {
    return (
      <div>
        <h2>Your Dashboard</h2>
        <p>Displays assigned: {data.displayCount}</p>
        <p>Advertisements uploaded: {data.adCount}</p>
        <h4>Campaigns by status</h4>
        <ul>{data.campaignCounts.map((c) => <li key={c.status}>{c.status}: {c.count}</li>)}</ul>
      </div>
    );
  }

  return (
    <div>
      <h2>Platform Dashboard</h2>
      <p>Total clients: {data.clientCount}</p>
      <p>Total displays: {data.displayCount}</p>
      <p>Pending approvals: {data.pendingApprovals}</p>
      <h4>Campaigns by status</h4>
      <ul>{data.campaignCounts.map((c) => <li key={c.status}>{c.status}: {c.count}</li>)}</ul>
    </div>
  );
}
