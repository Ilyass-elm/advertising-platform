import { useEffect, useState } from 'react';
import { createCampaign } from './campaigns.api';
import { listMyAds } from '../advertisements/advertisements.api';
import { listBrowsableDisplays } from '../displays/displays.api';

// Client builds an ORDERED sequence of creatives, each with its own play
// duration - array order IS play order, sent as-is to the backend which
// writes sequence_order from the array index (see campaigns.service.js).
export default function CampaignForm({ onCreated }) {
  const [ads, setAds] = useState([]);
  const [displays, setDisplays] = useState([]);
  const [form, setForm] = useState({
    name: '', startDate: '', endDate: '', timeStart: '09:00', timeEnd: '18:00',
    priority: 5, targetDisplayIds: [],
  });
  const [items, setItems] = useState([]); // [{ advertisementId, durationSeconds }]
  const [addAdId, setAddAdId] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    listMyAds().then(setAds);
    listBrowsableDisplays().then(setDisplays);
  }, []);

  function toggleTarget(id) {
    setForm((f) => ({
      ...f,
      targetDisplayIds: f.targetDisplayIds.includes(id)
        ? f.targetDisplayIds.filter((x) => x !== id)
        : [...f.targetDisplayIds, id],
    }));
  }

  function addItem() {
    if (!addAdId) return;
    setItems((its) => [...its, { advertisementId: addAdId, durationSeconds: 10 }]);
    setAddAdId('');
  }

  function removeItem(index) {
    setItems((its) => its.filter((_, i) => i !== index));
  }

  function moveItem(index, direction) {
    setItems((its) => {
      const next = [...its];
      const target = index + direction;
      if (target < 0 || target >= next.length) return its;
      [next[index], next[target]] = [next[target], next[index]];
      return next;
    });
  }

  function setDuration(index, value) {
    setItems((its) => its.map((it, i) => (i === index ? { ...it, durationSeconds: Number(value) } : it)));
  }

  function adTitle(adId) {
    return ads.find((a) => a.id === adId)?.title || '(unknown creative)';
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    if (form.targetDisplayIds.length === 0) return setError('Select at least one display');
    if (items.length === 0) return setError('Add at least one creative to the sequence');
    try {
      await createCampaign({
        name: form.name,
        startDate: form.startDate,
        endDate: form.endDate,
        timeStart: form.timeStart,
        timeEnd: form.timeEnd,
        priority: Number(form.priority),
        targets: form.targetDisplayIds.map((id) => ({ type: 'display', id })),
        items,
      });
      onCreated();
    } catch (err) {
      setError(err.response?.data?.error || 'Could not create campaign');
    }
  }

  return (
    <form onSubmit={handleSubmit} style={{ border: '1px solid #ddd', padding: 16, marginBottom: 16, maxWidth: 560 }}>
      <div><label>Name<br /><input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required /></label></div>
      <div><label>Start date<br /><input type="date" value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} required /></label></div>
      <div><label>End date<br /><input type="date" value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} required /></label></div>
      <div><label>Time start<br /><input type="time" value={form.timeStart} onChange={(e) => setForm({ ...form, timeStart: e.target.value })} /></label></div>
      <div><label>Time end<br /><input type="time" value={form.timeEnd} onChange={(e) => setForm({ ...form, timeEnd: e.target.value })} /></label></div>
      <div><label>Priority (1-10)<br /><input type="number" min="1" max="10" value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })} /></label></div>

      <div style={{ marginTop: 12 }}>
        <p>Target displays:</p>
        {displays.length === 0 && <p style={{ fontSize: 13, color: '#666' }}>No displays registered on the platform yet.</p>}
        {displays.map((d) => (
          <label key={d.id} style={{ display: 'block' }}>
            <input type="checkbox" checked={form.targetDisplayIds.includes(d.id)} onChange={() => toggleTarget(d.id)} />
            {' '}{d.name} — {d.location || 'location not set'}
          </label>
        ))}
      </div>

      <div style={{ marginTop: 16, borderTop: '1px solid #eee', paddingTop: 12 }}>
        <p>Creative sequence (play order + duration):</p>
        <div style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
          <select value={addAdId} onChange={(e) => setAddAdId(e.target.value)}>
            <option value="">-- choose a creative --</option>
            {ads.map((a) => <option key={a.id} value={a.id}>{a.title}</option>)}
          </select>
          <button type="button" onClick={addItem}>+ Add to sequence</button>
        </div>
        {items.length === 0 && <p style={{ fontSize: 13, color: '#666' }}>No creatives added yet.</p>}
        {items.map((it, index) => (
          <div key={index} style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 4 }}>
            <span style={{ width: 20 }}>{index + 1}.</span>
            <span style={{ flex: 1 }}>{adTitle(it.advertisementId)}</span>
            <input type="number" min="1" max="600" value={it.durationSeconds}
              onChange={(e) => setDuration(index, e.target.value)} style={{ width: 70 }} /> sec
            <button type="button" onClick={() => moveItem(index, -1)} disabled={index === 0}>↑</button>
            <button type="button" onClick={() => moveItem(index, 1)} disabled={index === items.length - 1}>↓</button>
            <button type="button" onClick={() => removeItem(index)}>Remove</button>
          </div>
        ))}
      </div>

      {error && <p style={{ color: 'red' }}>{error}</p>}
      <button type="submit" style={{ marginTop: 12 }}>Submit for approval</button>
    </form>
  );
}
