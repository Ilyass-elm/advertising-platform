import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../../auth/AuthContext';
import { listMyCampaigns, listAllCampaigns, stopCampaign } from './campaigns.api';
import CampaignForm from './CampaignForm';

const STATUS_COLORS = {
  pending: '#eab308', approved: '#22c55e', rejected: '#ef4444',
  active: '#3b82f6', stopped: '#f97316', completed: '#6b7280', archived: '#9ca3af', draft: '#d1d5db',
};

const STOPPABLE_STATUSES = ['approved', 'active', 'pending'];

export default function CampaignsPage() {
  const { user } = useAuth();
  const isClient = user.role === 'client';
  const [campaigns, setCampaigns] = useState([]);
  const [showForm, setShowForm] = useState(false);

  const refresh = () => (isClient ? listMyCampaigns() : listAllCampaigns()).then(setCampaigns);
  useEffect(() => { refresh(); }, []);

  async function handleStop(id) {
    if (!window.confirm('Stop this ad? It will be taken off every display immediately.')) return;
    await stopCampaign(id);
    refresh();
  }

  return (
    <div>
      <h2>{isClient ? 'My Campaigns' : 'All Campaigns'}</h2>
      {isClient && (
        <button onClick={() => setShowForm((s) => !s)} style={{ marginBottom: 16 }}>
          {showForm ? 'Cancel' : '+ New Campaign'}
        </button>
      )}
      {isClient && showForm && (
        <CampaignForm onCreated={() => { setShowForm(false); refresh(); }} />
      )}
      <table border="1" cellPadding="6" style={{ borderCollapse: 'collapse', width: '100%', marginTop: 16 }}>
        <thead>
          <tr>
            <th>Name</th>{!isClient && <th>Client</th>}<th>Dates</th><th>Priority</th><th>Status</th><th></th>
          </tr>
        </thead>
        <tbody>
          {campaigns.map((c) => (
            <tr key={c.id}>
              <td><Link to={`/campaigns/${c.id}`}>{c.name}</Link></td>
              {!isClient && <td>{c.company_name}</td>}
              <td>{c.start_date} → {c.end_date} ({c.time_start}-{c.time_end})</td>
              <td>{c.priority}</td>
              <td><span style={{ background: STATUS_COLORS[c.status], padding: '2px 8px', borderRadius: 4, color: '#fff' }}>{c.status}</span>
                {c.status === 'rejected' && c.rejection_reason && <div style={{ fontSize: 12 }}>{c.rejection_reason}</div>}
              </td>
              <td>{STOPPABLE_STATUSES.includes(c.status) && <button onClick={() => handleStop(c.id)}>Stop ad</button>}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
