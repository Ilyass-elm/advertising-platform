import apiClient from '../../api/client';

export const listGroups = () => apiClient.get('/display-groups').then((r) => r.data.data);
export const createGroup = (payload) => apiClient.post('/display-groups', payload).then((r) => r.data.data);
export const addMembers = (groupId, displayIds) =>
  apiClient.post(`/display-groups/${groupId}/members`, { displayIds }).then((r) => r.data.data);
