import apiClient from '../../api/client';

export const listMyAds = () => apiClient.get('/advertisements/mine').then((r) => r.data.data);

export const uploadAd = (file, title) => {
  const form = new FormData();
  form.append('file', file);
  form.append('title', title);
  return apiClient.post('/advertisements', form, {
    headers: { 'Content-Type': 'multipart/form-data' },
  }).then((r) => r.data.data);
};

// The file-preview endpoint is JWT-protected like everything else, but a
// plain <img src="..."> can't send an Authorization header - so we fetch it
// as a blob via the authenticated axios instance and hand back an object
// URL the browser can use directly. Caller is responsible for
// URL.revokeObjectURL() when done (see CreativePreview's cleanup effect).
export const fetchAdBlobUrl = (adId) =>
  apiClient.get(`/advertisements/${adId}/file`, { responseType: 'blob' }).then((r) => URL.createObjectURL(r.data));
