import { useEffect, useState } from 'react';
import { listClients } from './clients.api';

export default function ClientsPage() {
  const [clients, setClients] = useState([]);
  useEffect(() => { listClients().then(setClients); }, []);

  return (
    <div>
      <h2>Clients</h2>
      <table border="1" cellPadding="6" style={{ borderCollapse: 'collapse', width: '100%' }}>
        <thead><tr><th>Company</th><th>Contact</th><th>Email</th><th>Active</th></tr></thead>
        <tbody>
          {clients.map((c) => (
            <tr key={c.id}>
              <td>{c.company_name}</td><td>{c.full_name}</td><td>{c.email}</td><td>{c.is_active ? 'yes' : 'no'}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
