import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import apiClient from '../../api/client';
import CreativePreview from '../../components/CreativePreview';
import { listBrowsableDisplays } from '../displays/displays.api';

export default function CampaignDetailPage() {
  const { id } = useParams();
  const [campaign, setCampaign] = useState(null);
  const [error, setError] = useState('');
  const [displays, setDisplays] = useState([]);

  useEffect(() => {
    apiClient.get(`/campaigns/${id}`)
      .then((r) => setCampaign(r.data.data))
      .catch((err) => setError(err.response?.data?.error || 'Could not load campaign'));
  }, [id]);

  useEffect(() => { listBrowsableDisplays().then(setDisplays).catch(() => {}); }, []);

  if (error) return <p style={{ color: 'red' }}>{error}</p>;
  if (!campaign) return <p>Loading…</p>;

  return (
    <div>
      <p><Link to="/campaigns">← Back to campaigns</Link></p>
      <h2>{campaign.name}</h2>
      <p>
        Status: <strong>{campaign.status}</strong>
        {campaign.status === 'rejected' && campaign.rejection_reason && <span> — {campaign.rejection_reason}</span>}
      </p>
      <p>{campaign.start_date} → {campaign.end_date}, {campaign.time_start}-{campaign.time_end}, priority {campaign.priority}</p>

      <h4>Targets</h4>
      <ul>
        {campaign.targets.map((t) => {
          const d = displays.find((x) => x.id === t.id);
          return (
            <li key={t.id}>
              {t.type === 'display'
                ? <Link to={`/displays/${t.id}`}>{d ? `${d.name} — ${d.location || 'no location'}` : t.id}</Link>
                : `${t.type}: ${t.id}`}
            </li>
          );
        })}
      </ul>

      <h4>Creative sequence</h4>
      {campaign.items.map((item, index) => (
        <div key={item.id} style={{ border: '1px solid #ddd', padding: 12, marginBottom: 12, display: 'flex', gap: 16, alignItems: 'center' }}>
          <div style={{ width: 24, fontWeight: 'bold' }}>{index + 1}.</div>
          <CreativePreview
            advertisementId={item.advertisement_id}
            fileType={item.file_type}
            style={{ maxWidth: 240, maxHeight: 160, objectFit: 'contain', background: '#000' }}
          />
          <div>
            <div><strong>{item.title}</strong></div>
            <div style={{ fontSize: 13, color: '#666' }}>{item.file_type} · plays for {item.duration_seconds}s</div>
          </div>
        </div>
      ))}
    </div>
  );
}
