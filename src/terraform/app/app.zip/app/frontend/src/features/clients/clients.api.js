import apiClient from '../../api/client';

export const listClients = () => apiClient.get('/clients').then((r) => r.data.data);
