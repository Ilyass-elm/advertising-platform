import apiClient from '../../api/client';

export const listMyCampaigns = () => apiClient.get('/campaigns/mine').then((r) => r.data.data);
export const listAllCampaigns = (status) =>
  apiClient.get('/campaigns', { params: status ? { status } : {} }).then((r) => r.data.data);
export const createCampaign = (payload) => apiClient.post('/campaigns', payload).then((r) => r.data.data);
export const updateCampaign = (id, payload) => apiClient.patch(`/campaigns/${id}`, payload).then((r) => r.data.data);
export const stopCampaign = (id) => apiClient.post(`/campaigns/${id}/stop`).then((r) => r.data.data);
