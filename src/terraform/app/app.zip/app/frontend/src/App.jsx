import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './auth/AuthContext';
import ProtectedRoute from './routes/ProtectedRoute';
import Layout from './components/Layout';

import LoginPage from './features/auth/LoginPage';
import RegisterPage from './features/auth/RegisterPage';
import DashboardPage from './features/dashboard/DashboardPage';
import CampaignsPage from './features/campaigns/CampaignsPage';
import CampaignDetailPage from './features/campaigns/CampaignDetailPage';
import AdvertisementsPage from './features/advertisements/AdvertisementsPage';
import ApprovalsPage from './features/approvals/ApprovalsPage';
import DisplaysPage from './features/displays/DisplaysPage';
import DisplayNowPage from './features/displays/DisplayNowPage';
import DisplayGroupsPage from './features/displayGroups/DisplayGroupsPage';
import ClientsPage from './features/clients/ClientsPage';
import UsersPage from './features/users/UsersPage';

// Each route maps 1:1 to a module's page component. Adding/removing a module
// touches only this file plus its own feature folder.
export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route element={<ProtectedRoute><Layout /></ProtectedRoute>}>
            <Route path="/" element={<DashboardPage />} />
            <Route path="/campaigns" element={<CampaignsPage />} />
            <Route path="/campaigns/:id" element={<CampaignDetailPage />} />
            <Route path="/advertisements" element={<ProtectedRoute roles={['client']}><AdvertisementsPage /></ProtectedRoute>} />
            <Route path="/approvals" element={<ProtectedRoute roles={['admin', 'employee']}><ApprovalsPage /></ProtectedRoute>} />
            <Route path="/displays" element={<DisplaysPage />} />
            <Route path="/displays/:id" element={<DisplayNowPage />} />
            <Route path="/display-groups" element={<ProtectedRoute roles={['admin', 'employee']}><DisplayGroupsPage /></ProtectedRoute>} />
            <Route path="/clients" element={<ProtectedRoute roles={['admin', 'employee']}><ClientsPage /></ProtectedRoute>} />
            <Route path="/users" element={<ProtectedRoute roles={['admin']}><UsersPage /></ProtectedRoute>} />
          </Route>
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
