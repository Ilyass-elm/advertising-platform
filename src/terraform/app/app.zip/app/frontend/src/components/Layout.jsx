import { Link, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';
import ErrorBoundary from './ErrorBoundary';

// Nav links are filtered by role so each role only sees modules it can use -
// the backend still enforces permissions independently, this is just UX.
const NAV = [
  { to: '/', label: 'Dashboard', roles: ['admin', 'employee', 'client'] },
  { to: '/campaigns', label: 'Campaigns', roles: ['admin', 'employee', 'client'] },
  { to: '/advertisements', label: 'Advertisements', roles: ['client'] },
  { to: '/approvals', label: 'Approvals', roles: ['admin', 'employee'] },
  { to: '/displays', label: 'Displays', roles: ['admin', 'employee', 'client'] },
  { to: '/display-groups', label: 'Display Groups', roles: ['admin', 'employee'] },
  { to: '/clients', label: 'Clients', roles: ['admin', 'employee'] },
  { to: '/users', label: 'Users', roles: ['admin'] },
];

export default function Layout() {
  const { user, logout } = useAuth();
  const location = useLocation();

  return (
    <div style={{ fontFamily: 'system-ui, sans-serif', display: 'flex', minHeight: '100vh' }}>
      <nav style={{ width: 220, borderRight: '1px solid #ddd', padding: 16 }}>
        <h3>Signage Platform</h3>
        <div style={{ fontSize: 13, color: '#666', marginBottom: 16 }}>
          {user?.fullName} ({user?.role})
        </div>
        <ul style={{ listStyle: 'none', padding: 0, display: 'flex', flexDirection: 'column', gap: 8 }}>
          {NAV.filter((n) => n.roles.includes(user?.role)).map((n) => (
            <li key={n.to}><Link to={n.to}>{n.label}</Link></li>
          ))}
        </ul>
        <button onClick={logout} style={{ marginTop: 24 }}>Log out</button>
      </nav>
      <main style={{ flex: 1, padding: 24 }}>
        <ErrorBoundary key={location.pathname}>
          <Outlet />
        </ErrorBoundary>
      </main>
    </div>
  );
}
