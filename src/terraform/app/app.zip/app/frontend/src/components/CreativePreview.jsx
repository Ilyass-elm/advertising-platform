import { useEffect, useState } from 'react';
import { fetchAdBlobUrl } from '../features/advertisements/advertisements.api';

// Fetches the actual file once (authenticated blob fetch - see
// advertisements.api.js for why a plain <img src> can't do this directly),
// then renders it as an image or video. Revokes the object URL on unmount
// so repeated previews don't leak memory.
export default function CreativePreview({ advertisementId, fileType, style }) {
  const [src, setSrc] = useState(null);
  const [error, setError] = useState(false);

  useEffect(() => {
    let objectUrl;
    let cancelled = false;
    fetchAdBlobUrl(advertisementId)
      .then((url) => {
        if (cancelled) { URL.revokeObjectURL(url); return; }
        objectUrl = url;
        setSrc(url);
      })
      .catch(() => setError(true));
    return () => {
      cancelled = true;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [advertisementId]);

  if (error) return <div style={{ ...style, color: '#999', fontSize: 12 }}>Preview unavailable</div>;
  if (!src) return <div style={{ ...style, color: '#999', fontSize: 12 }}>Loading preview…</div>;

  return fileType === 'video'
    ? <video src={src} controls style={style} />
    : <img src={src} alt="" style={style} />;
}
