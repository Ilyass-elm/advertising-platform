import { Component } from 'react';

// Wraps the routed page content (not the nav) so a bug in one module's page
// shows an inline error instead of unmounting the entire app - the exact
// failure mode that made the whole left nav disappear when DisplayGroupsPage
// threw during render.
export default class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { error: null };
  }

  static getDerivedStateFromError(error) {
    return { error };
  }

  componentDidCatch(error, info) {
    console.error('Page crashed:', error, info);
  }

  render() {
    if (this.state.error) {
      return (
        <div style={{ padding: 16, border: '1px solid #f87171', background: '#fef2f2' }}>
          <strong>Something went wrong loading this page.</strong>
          <p style={{ fontSize: 13, color: '#7f1d1d' }}>{String(this.state.error.message || this.state.error)}</p>
          <button onClick={() => this.setState({ error: null })}>Try again</button>
        </div>
      );
    }
    return this.props.children;
  }
}
