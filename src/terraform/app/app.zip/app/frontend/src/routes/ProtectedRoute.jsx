import { Navigate } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';

// Wrap any route element: <ProtectedRoute roles={['admin','employee']}><Page/></ProtectedRoute>
// roles omitted = any authenticated user is allowed.
export default function ProtectedRoute({ children, roles }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (roles && !roles.includes(user.role)) return <Navigate to="/" replace />;
  return children;
}
