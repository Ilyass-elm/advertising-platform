#!/bin/sh
set -e

node src/db/seed.js

npm run dev -- --host ${s3_bucket_name} --port 4000
