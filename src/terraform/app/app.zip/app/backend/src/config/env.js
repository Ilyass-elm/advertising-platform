require('dotenv').config();

module.exports = {
  port: process.env.PORT || 4000,
  nodeEnv: process.env.NODE_ENV || 'development',
  jwtSecret: process.env.JWT_SECRET || 'dev-secret',
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '8h',
  dbFile: process.env.DB_FILE || './data/signage.db',
  uploadDir: process.env.UPLOAD_DIR || './src/uploads',
  storageDriver: process.env.STORAGE_DRIVER || 'local', // 'local' | 's3'
  s3Bucket: process.env.S3_BUCKET || '',
  awsRegion: process.env.AWS_REGION || 'eu-central-1',
};
