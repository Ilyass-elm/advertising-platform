const fs = require('fs');
const path = require('path');
const app = require('./app');
const env = require('./config/env');
const db = require('./config/db');

// Auto-apply schema on boot if tables don't exist yet - convenient for the
// MVP; swap for a real migration runner (e.g. node-pg-migrate) once this
// moves off SQLite.
const schema = fs.readFileSync(path.join(__dirname, 'db', 'schema.sql'), 'utf8');
db.exec(schema);

app.listen(env.port, () => {
  console.log(`Signage backend listening on http://localhost:${env.port}`);
});
