// Creates a default admin and one demo client so the API is usable immediately
// after `npm run migrate`. Run with: node src/db/seed.js
const bcrypt = require('bcryptjs');
const { v4: uuid } = require('uuid');
const db = require('../config/db');

const adminId = uuid();
const clientUserId = uuid();
const clientId = uuid();

db.prepare(`INSERT OR IGNORE INTO users (id, email, password_hash, role, full_name) VALUES (?, ?, ?, 'admin', ?)`)
  .run(adminId, 'admin@signage.local', bcrypt.hashSync('admin1234', 10), 'Platform Admin');

db.prepare(`INSERT OR IGNORE INTO users (id, email, password_hash, role, full_name) VALUES (?, ?, ?, 'client', ?)`)
  .run(clientUserId, 'client@signage.local', bcrypt.hashSync('client1234', 10), 'Demo Client User');

db.prepare(`INSERT OR IGNORE INTO clients (id, user_id, company_name) VALUES (?, ?, ?)`)
  .run(clientId, clientUserId, 'Demo GmbH');

console.log('Seeded:');
console.log('  admin@signage.local / admin1234');
console.log('  client@signage.local / client1234');
