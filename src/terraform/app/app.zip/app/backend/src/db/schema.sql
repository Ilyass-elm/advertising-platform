-- Users: covers admin, employee, client (role-based, single table for auth simplicity;
-- role-specific data lives in the "clients" module table).
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('admin', 'employee', 'client')),
  full_name TEXT NOT NULL,
  is_active INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Client company profile, 1:1 with a user of role 'client'.
CREATE TABLE IF NOT EXISTS clients (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
  company_name TEXT NOT NULL,
  contact_phone TEXT,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Simplified on purpose: no device/screen layer for now. A display is just a
-- named, located slot that a campaign can target - nothing authenticates as
-- one, nothing reports its status.
CREATE TABLE IF NOT EXISTS displays (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  location TEXT,
  client_id TEXT REFERENCES clients(id) ON DELETE SET NULL,
  registered_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS display_groups (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  client_id TEXT REFERENCES clients(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS display_group_members (
  group_id TEXT NOT NULL REFERENCES display_groups(id) ON DELETE CASCADE,
  display_id TEXT NOT NULL REFERENCES displays(id) ON DELETE CASCADE,
  PRIMARY KEY (group_id, display_id)
);

-- A creative asset. Duration/order are NOT stored here - the same creative
-- can be reused across campaigns with a different duration each time, so
-- that belongs on campaign_items, not the asset itself.
-- storage_driver is recorded per-row (not just read from current env) so
-- switching STORAGE_DRIVER later doesn't break retrieval of files uploaded
-- under the previous driver.
CREATE TABLE IF NOT EXISTS advertisements (
  id TEXT PRIMARY KEY,
  client_id TEXT NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  file_path TEXT NOT NULL,            -- local: filename in uploads dir; s3: object key
  file_type TEXT NOT NULL CHECK (file_type IN ('image', 'video')),
  storage_driver TEXT NOT NULL DEFAULT 'local' CHECK (storage_driver IN ('local', 's3')),
  checksum TEXT,
  uploaded_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS campaigns (
  id TEXT PRIMARY KEY,
  client_id TEXT NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  start_date TEXT NOT NULL,
  end_date TEXT NOT NULL,
  time_start TEXT NOT NULL DEFAULT '00:00',
  time_end TEXT NOT NULL DEFAULT '23:59',
  priority INTEGER NOT NULL DEFAULT 5,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (
    status IN ('draft', 'pending', 'approved', 'rejected', 'active', 'stopped', 'completed', 'archived')
  ),
  rejection_reason TEXT,
  reviewed_by TEXT REFERENCES users(id),
  reviewed_at TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- A campaign can now play more than one creative, in a client-chosen order,
-- each with its own on-screen duration. sequence_order is 1-based and dense
-- (1,2,3,...) - the service layer always rewrites the whole set together so
-- there's never a gap to worry about.
CREATE TABLE IF NOT EXISTS campaign_items (
  id TEXT PRIMARY KEY,
  campaign_id TEXT NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
  advertisement_id TEXT NOT NULL REFERENCES advertisements(id),
  sequence_order INTEGER NOT NULL,
  duration_seconds INTEGER NOT NULL DEFAULT 10
);

-- A campaign targets one or more displays and/or display groups.
CREATE TABLE IF NOT EXISTS campaign_targets (
  id TEXT PRIMARY KEY,
  campaign_id TEXT NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
  target_type TEXT NOT NULL CHECK (target_type IN ('display', 'group')),
  target_id TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_campaign_targets_campaign ON campaign_targets(campaign_id);
CREATE INDEX IF NOT EXISTS idx_campaign_items_campaign ON campaign_items(campaign_id);
CREATE INDEX IF NOT EXISTS idx_campaigns_client ON campaigns(client_id);
CREATE INDEX IF NOT EXISTS idx_campaigns_status ON campaigns(status);
CREATE INDEX IF NOT EXISTS idx_displays_client ON displays(client_id);
