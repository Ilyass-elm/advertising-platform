const { AppError } = require('./errors');

// Central error handler: every module throws AppError subclasses (or lets
// zod errors bubble up) and this is the single place that turns them into
// an HTTP response. Keeps error formatting out of every controller.
module.exports = function errorHandler(err, req, res, next) { // eslint-disable-line
  if (err instanceof AppError) {
    return res.status(err.status).json({ success: false, error: err.message, details: err.details });
  }

  if (err.name === 'ZodError') {
    return res.status(422).json({ success: false, error: 'Validation failed', details: err.issues });
  }

  console.error(err);
  return res.status(500).json({ success: false, error: 'Internal server error' });
};
