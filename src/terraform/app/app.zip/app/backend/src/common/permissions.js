const { ForbiddenError, UnauthorizedError } = require('./errors');

// requireRole('admin', 'employee') -> only those roles may pass.
// Works on req.user, set by the auth middleware (JWT) for human users.
function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user) return next(new UnauthorizedError());
    if (!roles.includes(req.user.role)) return next(new ForbiddenError('Insufficient role'));
    next();
  };
}

// Staff = admin or employee, used a lot across modules for "internal" views.
const requireStaff = requireRole('admin', 'employee');
const requireAdmin = requireRole('admin');
const requireClient = requireRole('client');

module.exports = { requireRole, requireStaff, requireAdmin, requireClient };
