/**
 * Storage abstraction for creative files. Everything above this module
 * (advertisements.service.js, .controller.js) talks to saveFile()/getFileUrl()
 * only - which driver is actually active is decided once, here, by
 * env.storageDriver. Adding a third backend later (e.g. GCS) means adding a
 * case here, not touching the advertisements module at all.
 */
const fs = require('fs');
const path = require('path');
const env = require('../config/env');

const EXT_BY_MIME = {
  'image/png': '.png', 'image/jpeg': '.jpg', 'image/webp': '.webp', 'image/gif': '.gif',
  'video/mp4': '.mp4', 'video/webm': '.webm',
};

const localUploadDir = path.resolve(process.cwd(), env.uploadDir);

let s3Client = null;
function getS3Client() {
  if (s3Client) return s3Client;
  const { S3Client } = require('@aws-sdk/client-s3');
  s3Client = new S3Client({ region: env.awsRegion });
  return s3Client;
}

/**
 * Persists an uploaded file and returns { filePath, storageDriver } to store
 * on the advertisements row. `file` is a multer file object - diskStorage
 * shape (has .path/.filename) when driver is 'local', memoryStorage shape
 * (has .buffer) when driver is 's3'. See advertisements.upload.js, which
 * picks the matching multer storage engine based on the same env value.
 */
async function saveFile(file, { clientId, adId }) {
  if (env.storageDriver === 's3') {
    const { PutObjectCommand } = require('@aws-sdk/client-s3');
    const key = `advertisements/${clientId}/${adId}${EXT_BY_MIME[file.mimetype] || ''}`;
    await getS3Client().send(new PutObjectCommand({
      Bucket: env.s3Bucket,
      Key: key,
      Body: file.buffer,
      ContentType: file.mimetype,
    }));
    return { filePath: key, storageDriver: 's3' };
  }

  // local: multer's diskStorage already wrote the file under localUploadDir -
  // nothing left to do but record the filename it chose.
  return { filePath: file.filename, storageDriver: 'local' };
}

/** Reads the raw bytes back, for checksum computation at upload time. */
function readBytesForChecksum(file) {
  if (env.storageDriver === 's3') return file.buffer;
  return fs.readFileSync(file.path);
}

/**
 * Resolves how the browser should actually fetch a stored file:
 * - local -> an absolute path on disk, for res.sendFile()
 * - s3    -> a short-lived signed URL, for a redirect
 * Kept as two distinct return shapes (not a single "url") so the controller
 * can pick sendFile vs redirect explicitly rather than guessing from a string.
 */
async function resolveForServing(ad) {
  if (ad.storage_driver === 's3') {
    const { GetObjectCommand } = require('@aws-sdk/client-s3');
    const { getSignedUrl } = require('@aws-sdk/s3-request-presigner');
    const url = await getSignedUrl(
      getS3Client(),
      new GetObjectCommand({ Bucket: env.s3Bucket, Key: ad.file_path }),
      { expiresIn: 300 }
    );
    return { kind: 'redirect', url };
  }

  const filePath = path.join(localUploadDir, ad.file_path);
  return { kind: 'file', filePath, exists: fs.existsSync(filePath) };
}

module.exports = { saveFile, readBytesForChecksum, resolveForServing, localUploadDir };
