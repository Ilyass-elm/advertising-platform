// Small helpers so every module returns responses in the same shape.
function ok(res, data, status = 200) {
  return res.status(status).json({ success: true, data });
}

function fail(res, message, status = 400, details) {
  return res.status(status).json({ success: false, error: message, details });
}

module.exports = { ok, fail };
