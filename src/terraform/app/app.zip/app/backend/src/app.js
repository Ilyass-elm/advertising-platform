const express = require('express');
const cors = require('cors');

const errorHandler = require('./common/errorHandler');

// Each module owns and exports its own router. app.js only wires paths -
// it has no business logic of its own, so modules stay swappable.
const authRoutes = require('./modules/auth/auth.routes');
const usersRoutes = require('./modules/users/users.routes');
const clientsRoutes = require('./modules/clients/clients.routes');
const campaignsRoutes = require('./modules/campaigns/campaigns.routes');
const advertisementsRoutes = require('./modules/advertisements/advertisements.routes');
const displaysRoutes = require('./modules/displays/displays.routes');
const displayGroupsRoutes = require('./modules/displayGroups/displayGroups.routes');
const approvalsRoutes = require('./modules/approvals/approvals.routes');
const dashboardRoutes = require('./modules/dashboard/dashboard.routes');

const app = express();

app.use(cors());
app.use(express.json());

app.get('/api/health', (req, res) => res.json({ success: true, data: { status: 'ok' } }));

app.use('/api/auth', authRoutes);
app.use('/api/users', usersRoutes);
app.use('/api/clients', clientsRoutes);
app.use('/api/campaigns', campaignsRoutes);
app.use('/api/advertisements', advertisementsRoutes);
app.use('/api/displays', displaysRoutes);
app.use('/api/display-groups', displayGroupsRoutes);
app.use('/api/approvals', approvalsRoutes);
app.use('/api/dashboard', dashboardRoutes);

app.use((req, res) => res.status(404).json({ success: false, error: 'Not found' }));
app.use(errorHandler);

module.exports = app;
