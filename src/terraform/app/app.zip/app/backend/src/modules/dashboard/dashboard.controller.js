const service = require('./dashboard.service');
const { ok } = require('../../common/apiResponse');
const clientsService = require('../clients/clients.service');

function get(req, res) {
  if (req.user.role === 'client') {
    const client = clientsService.getByUserId(req.user.id);
    return ok(res, { role: 'client', ...service.clientDashboard(client.id) });
  }
  return ok(res, { role: req.user.role, ...service.staffDashboard() });
}

module.exports = { get };
