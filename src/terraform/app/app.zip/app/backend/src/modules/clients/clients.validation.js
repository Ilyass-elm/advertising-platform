const { z } = require('zod');

const updateClientSchema = z.object({
  companyName: z.string().min(2).optional(),
  contactPhone: z.string().optional(),
  notes: z.string().optional(),
});

module.exports = { updateClientSchema };
