const express = require('express');
const controller = require('./users.controller');
const { authenticateUser } = require('../auth/auth.middleware');
const { requireAdmin } = require('../../common/permissions');
const asyncHandler = require('../../common/asyncHandler');

const router = express.Router();
router.use(authenticateUser, requireAdmin); // whole module: admin-only ("Manage users where appropriate")

router.get('/', asyncHandler(controller.list));
router.get('/:id', asyncHandler(controller.get));
router.post('/', asyncHandler(controller.createStaff));
router.patch('/:id', asyncHandler(controller.update));

module.exports = router;
