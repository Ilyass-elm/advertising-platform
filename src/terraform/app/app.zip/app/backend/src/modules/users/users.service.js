const bcrypt = require('bcryptjs');
const { v4: uuid } = require('uuid');
const db = require('../../config/db');
const { NotFoundError } = require('../../common/errors');

function list() {
  return db.prepare('SELECT id, email, role, full_name, is_active, created_at FROM users ORDER BY created_at DESC').all();
}

function getById(id) {
  const user = db.prepare('SELECT id, email, role, full_name, is_active, created_at FROM users WHERE id = ?').get(id);
  if (!user) throw new NotFoundError('User not found');
  return user;
}

// Admin/employee accounts are provisioned by an existing admin (no public
// self-registration for staff, unlike clients).
function createStaff({ email, password, fullName, role }) {
  const id = uuid();
  const passwordHash = bcrypt.hashSync(password, 10);
  db.prepare(
    `INSERT INTO users (id, email, password_hash, role, full_name) VALUES (?, ?, ?, ?, ?)`
  ).run(id, email, passwordHash, role, fullName);
  return getById(id);
}

function update(id, patch) {
  const user = getById(id);
  const fullName = patch.fullName ?? user.full_name;
  const isActive = patch.isActive === undefined ? user.is_active : (patch.isActive ? 1 : 0);
  db.prepare(`UPDATE users SET full_name = ?, is_active = ?, updated_at = datetime('now') WHERE id = ?`)
    .run(fullName, isActive, id);
  return getById(id);
}

module.exports = { list, getById, createStaff, update };
