const { v4: uuid } = require('uuid');
const db = require('../../config/db');
const { NotFoundError, ForbiddenError, ValidationError } = require('../../common/errors');
const adsService = require('../advertisements/advertisements.service');

function withTargets(campaign) {
  const targets = db.prepare('SELECT target_type as type, target_id as id FROM campaign_targets WHERE campaign_id = ?')
    .all(campaign.id);
  return { ...campaign, targets };
}

// Ordered creative sequence, each joined with its own title/type for display
// without a second round-trip from the frontend.
function withItems(campaign) {
  const items = db.prepare(
    `SELECT ci.id, ci.advertisement_id, ci.sequence_order, ci.duration_seconds,
            a.title, a.file_type
     FROM campaign_items ci JOIN advertisements a ON a.id = ci.advertisement_id
     WHERE ci.campaign_id = ? ORDER BY ci.sequence_order ASC`
  ).all(campaign.id);
  return { ...campaign, items };
}

function withDetails(campaign) {
  return withItems(withTargets(campaign));
}

function getById(id) {
  const campaign = db.prepare('SELECT * FROM campaigns WHERE id = ?').get(id);
  if (!campaign) throw new NotFoundError('Campaign not found');
  return withDetails(campaign);
}

function listForClient(clientId) {
  return db.prepare('SELECT * FROM campaigns WHERE client_id = ? ORDER BY created_at DESC').all(clientId).map(withDetails);
}

function listAll(filter = {}) {
  let sql = `SELECT ca.*, cl.company_name FROM campaigns ca JOIN clients cl ON cl.id = ca.client_id`;
  const params = [];
  if (filter.status) {
    sql += ' WHERE ca.status = ?';
    params.push(filter.status);
  }
  sql += ' ORDER BY ca.created_at DESC';
  return db.prepare(sql).all(...params).map(withDetails);
}

function assertOwnedByClient(campaignId, clientId) {
  const campaign = getById(campaignId);
  if (campaign.client_id !== clientId) throw new ForbiddenError('Campaign does not belong to this client');
  return campaign;
}

function saveTargets(campaignId, targets) {
  db.prepare('DELETE FROM campaign_targets WHERE campaign_id = ?').run(campaignId);
  const stmt = db.prepare('INSERT INTO campaign_targets (id, campaign_id, target_type, target_id) VALUES (?, ?, ?, ?)');
  const tx = db.transaction((rows) => rows.forEach((t) => stmt.run(uuid(), campaignId, t.type, t.id)));
  tx(targets);
}

// Rewrites the whole ordered sequence - array index becomes sequence_order,
// 1-based. Simpler and less error-prone than trying to diff/patch individual
// positions, and the client always sends the full current order anyway.
function saveItems(campaignId, clientId, items) {
  items.forEach((item) => adsService.assertOwnedByClient(item.advertisementId, clientId));

  db.prepare('DELETE FROM campaign_items WHERE campaign_id = ?').run(campaignId);
  const stmt = db.prepare(
    `INSERT INTO campaign_items (id, campaign_id, advertisement_id, sequence_order, duration_seconds)
     VALUES (?, ?, ?, ?, ?)`
  );
  const tx = db.transaction((rows) => rows.forEach((it, index) =>
    stmt.run(uuid(), campaignId, it.advertisementId, index + 1, it.durationSeconds)
  ));
  tx(items);
}

// New campaigns always start life as 'pending' review - clients cannot
// self-approve. This is the enforcement point for the approval workflow.
function create(clientId, input) {
  if (new Date(input.startDate) > new Date(input.endDate)) {
    throw new ValidationError('startDate must be before endDate');
  }

  const id = uuid();
  db.prepare(
    `INSERT INTO campaigns
      (id, client_id, name, start_date, end_date, time_start, time_end, priority, status)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')`
  ).run(id, clientId, input.name, input.startDate, input.endDate, input.timeStart, input.timeEnd, input.priority);

  saveTargets(id, input.targets);
  saveItems(id, clientId, input.items);
  return getById(id);
}

// Editing an already-approved/active campaign resets it to 'pending' so an
// approver reviews the change before it's considered live again.
function update(campaignId, clientId, patch) {
  const campaign = assertOwnedByClient(campaignId, clientId);
  if (['completed', 'archived'].includes(campaign.status)) {
    throw new ValidationError(`Cannot edit a campaign with status "${campaign.status}"`);
  }

  const merged = {
    name: patch.name ?? campaign.name,
    startDate: patch.startDate ?? campaign.start_date,
    endDate: patch.endDate ?? campaign.end_date,
    timeStart: patch.timeStart ?? campaign.time_start,
    timeEnd: patch.timeEnd ?? campaign.time_end,
    priority: patch.priority ?? campaign.priority,
  };

  const needsReReview = campaign.status === 'approved' || campaign.status === 'active';
  db.prepare(
    `UPDATE campaigns SET name=?, start_date=?, end_date=?, time_start=?, time_end=?,
       priority=?, status=?, updated_at=datetime('now') WHERE id=?`
  ).run(merged.name, merged.startDate, merged.endDate, merged.timeStart, merged.timeEnd,
    merged.priority, needsReReview ? 'pending' : campaign.status, campaignId);

  if (patch.targets) saveTargets(campaignId, patch.targets);
  if (patch.items) saveItems(campaignId, clientId, patch.items);
  return getById(campaignId);
}

function setStatus(campaignId, status, reviewerId, rejectionReason) {
  getById(campaignId);
  db.prepare(
    `UPDATE campaigns SET status=?, rejection_reason=?, reviewed_by=?, reviewed_at=datetime('now'), updated_at=datetime('now')
     WHERE id=?`
  ).run(status, rejectionReason || null, reviewerId, campaignId);
  return getById(campaignId);
}

module.exports = { getById, listForClient, listAll, assertOwnedByClient, create, update, setStatus };
