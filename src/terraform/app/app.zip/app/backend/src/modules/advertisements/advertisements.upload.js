const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { v4: uuid } = require('uuid');
const env = require('../../config/env');
const { localUploadDir } = require('../../common/storage');

const ALLOWED = {
  'image/png': 'image', 'image/jpeg': 'image', 'image/webp': 'image', 'image/gif': 'image',
  'video/mp4': 'video', 'video/webm': 'video',
};

// Local driver: multer writes straight to disk (existing behavior).
// S3 driver: multer just buffers the file in memory - storage.js does the
// actual upload to the bucket from advertisements.service.js, after title
// validation has already passed, so a rejected upload never touches S3.
if (env.storageDriver === 'local') {
  fs.mkdirSync(localUploadDir, { recursive: true });
}

const storageEngine = env.storageDriver === 's3'
  ? multer.memoryStorage()
  : multer.diskStorage({
      destination: (req, file, cb) => cb(null, localUploadDir),
      filename: (req, file, cb) => cb(null, `${uuid()}${path.extname(file.originalname)}`),
    });

const upload = multer({
  storage: storageEngine,
  limits: { fileSize: 200 * 1024 * 1024 }, // 200MB, generous for signage video creatives
  fileFilter: (req, file, cb) => {
    if (!ALLOWED[file.mimetype]) return cb(new Error(`Unsupported file type: ${file.mimetype}`));
    cb(null, true);
  },
});

module.exports = { upload, ALLOWED };
