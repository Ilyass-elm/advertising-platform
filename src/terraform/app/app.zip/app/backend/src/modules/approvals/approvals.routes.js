const express = require('express');
const controller = require('./approvals.controller');
const { authenticateUser } = require('../auth/auth.middleware');
const { requireStaff } = require('../../common/permissions');
const asyncHandler = require('../../common/asyncHandler');

const router = express.Router();
router.use(authenticateUser, requireStaff); // "Approve/reject campaigns" is a staff-only action

router.get('/queue', asyncHandler(controller.queue));
router.post('/:campaignId/review', asyncHandler(controller.review));

module.exports = router;
