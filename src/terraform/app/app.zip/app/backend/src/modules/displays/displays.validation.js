const { z } = require('zod');

const createDisplaySchema = z.object({
  name: z.string().min(2),
  location: z.string().optional(),
  clientId: z.string().optional(), // staff assigns a display to a client
});

const assignSchema = z.object({ clientId: z.string().nullable() });

module.exports = { createDisplaySchema, assignSchema };
