const campaignsService = require('../campaigns/campaigns.service');

// Thin, dedicated module for the approval workflow, kept separate from
// campaigns.service so "who can approve and what happens on approval" can
// evolve independently (e.g. multi-step approval, notifications) without
// touching campaign CRUD.
function pendingQueue() {
  return campaignsService.listAll({ status: 'pending' });
}

function review(campaignId, reviewerId, { decision, rejectionReason }) {
  return campaignsService.setStatus(campaignId, decision, reviewerId, rejectionReason);
}

module.exports = { pendingQueue, review };
