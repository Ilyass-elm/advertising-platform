const { v4: uuid } = require('uuid');
const crypto = require('crypto');
const db = require('../../config/db');
const { NotFoundError, ForbiddenError } = require('../../common/errors');
const storage = require('../../common/storage');

function listForClient(clientId) {
  return db.prepare('SELECT * FROM advertisements WHERE client_id = ? ORDER BY uploaded_at DESC').all(clientId);
}

function listAll() {
  return db.prepare(
    `SELECT a.*, c.company_name FROM advertisements a JOIN clients c ON c.id = a.client_id ORDER BY a.uploaded_at DESC`
  ).all();
}

function getById(id) {
  const ad = db.prepare('SELECT * FROM advertisements WHERE id = ?').get(id);
  if (!ad) throw new NotFoundError('Advertisement not found');
  return ad;
}

function assertOwnedByClient(adId, clientId) {
  const ad = getById(adId);
  if (ad.client_id !== clientId) throw new ForbiddenError('Advertisement does not belong to this client');
  return ad;
}

async function create({ clientId, title, file }) {
  const id = uuid();
  const fileType = { 'image/png': 'image', 'image/jpeg': 'image', 'image/webp': 'image', 'image/gif': 'image',
    'video/mp4': 'video', 'video/webm': 'video' }[file.mimetype];
  const checksum = crypto.createHash('sha256').update(storage.readBytesForChecksum(file)).digest('hex');
  const { filePath, storageDriver } = await storage.saveFile(file, { clientId, adId: id });

  db.prepare(
    `INSERT INTO advertisements (id, client_id, title, file_path, file_type, storage_driver, checksum)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run(id, clientId, title, filePath, fileType, storageDriver, checksum);

  return getById(id);
}

module.exports = { listForClient, listAll, getById, assertOwnedByClient, create };
