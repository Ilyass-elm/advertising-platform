const service = require('./users.service');
const { createStaffSchema, updateUserSchema } = require('./users.validation');
const { ok } = require('../../common/apiResponse');

function list(req, res) {
  ok(res, service.list());
}

function get(req, res) {
  ok(res, service.getById(req.params.id));
}

function createStaff(req, res) {
  const input = createStaffSchema.parse(req.body);
  ok(res, service.createStaff(input), 201);
}

function update(req, res) {
  const input = updateUserSchema.parse(req.body);
  ok(res, service.update(req.params.id, input));
}

module.exports = { list, get, createStaff, update };
