const db = require('../../config/db');

function clientDashboard(clientId) {
  const campaignCounts = db.prepare(
    `SELECT status, COUNT(*) as count FROM campaigns WHERE client_id = ? GROUP BY status`
  ).all(clientId);
  const displayCount = db.prepare('SELECT COUNT(*) as count FROM displays WHERE client_id = ?').get(clientId).count;
  const adCount = db.prepare('SELECT COUNT(*) as count FROM advertisements WHERE client_id = ?').get(clientId).count;
  return { campaignCounts, displayCount, adCount };
}

function staffDashboard() {
  const campaignCounts = db.prepare('SELECT status, COUNT(*) as count FROM campaigns GROUP BY status').all();
  const displayCount = db.prepare('SELECT COUNT(*) as count FROM displays').get().count;
  const clientCount = db.prepare('SELECT COUNT(*) as count FROM clients').get().count;
  const pendingApprovals = db.prepare(`SELECT COUNT(*) as count FROM campaigns WHERE status = 'pending'`).get().count;
  return { campaignCounts, displayCount, clientCount, pendingApprovals };
}

module.exports = { clientDashboard, staffDashboard };
