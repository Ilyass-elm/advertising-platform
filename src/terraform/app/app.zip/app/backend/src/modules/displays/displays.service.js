const { v4: uuid } = require('uuid');
const db = require('../../config/db');
const { NotFoundError } = require('../../common/errors');
const campaignsService = require('../campaigns/campaigns.service');

function listAll() {
  return db.prepare(
    `SELECT d.*, c.company_name FROM displays d LEFT JOIN clients c ON c.id = d.client_id ORDER BY d.registered_at DESC`
  ).all();
}

// What a client sees when choosing WHERE to target a campaign - any display
// on the platform, independent of which client (if any) it's "assigned" to.
function listBrowsable() {
  return db.prepare(`SELECT id, name, location FROM displays ORDER BY name`).all();
}

function listForClient(clientId) {
  return db.prepare('SELECT * FROM displays WHERE client_id = ? ORDER BY registered_at DESC').all(clientId);
}

function getById(id) {
  const display = db.prepare('SELECT * FROM displays WHERE id = ?').get(id);
  if (!display) throw new NotFoundError('Display not found');
  return display;
}

function create({ name, location, clientId }) {
  const id = uuid();
  db.prepare('INSERT INTO displays (id, name, location, client_id) VALUES (?, ?, ?, ?)')
    .run(id, name, location || null, clientId || null);
  return getById(id);
}

function assignClient(id, clientId) {
  getById(id);
  db.prepare('UPDATE displays SET client_id = ? WHERE id = ?').run(clientId, id);
  return getById(id);
}

function inTimeWindow(start, end, nowHM) {
  // handles overnight windows too (e.g. 22:00-06:00)
  return start <= end ? (nowHM >= start && nowHM <= end) : (nowHM >= start || nowHM <= end);
}

// "What is running on this display": derived from approved/active campaigns
// that target it directly OR through a display group it belongs to. There is
// no device reporting back, so this is what SHOULD be playing according to
// the schedule - split into playing-now vs approved-but-waiting (with the
// reason) so it's useful for troubleshooting "why isn't my ad showing".
// Times are server time (UTC in Docker) - returned so the UI can show it.
// onlyClientId scopes the result to one client's campaigns (client role).
function getPlayingNow(displayId, { onlyClientId } = {}) {
  const display = getById(displayId);
  const now = new Date();
  const today = now.toISOString().slice(0, 10);
  const nowHM = now.toISOString().slice(11, 16);

  let sql = `SELECT DISTINCT ca.id, cl.company_name
     FROM campaigns ca
     JOIN clients cl ON cl.id = ca.client_id
     JOIN campaign_targets ct ON ct.campaign_id = ca.id
     WHERE ca.status IN ('approved', 'active')
       AND ca.end_date >= ?
       AND ((ct.target_type = 'display' AND ct.target_id = ?)
         OR (ct.target_type = 'group' AND ct.target_id IN
              (SELECT group_id FROM display_group_members WHERE display_id = ?)))`;
  const params = [today, displayId, displayId];
  if (onlyClientId) {
    sql += ' AND ca.client_id = ?';
    params.push(onlyClientId);
  }

  const playing = [];
  const waiting = [];
  db.prepare(sql).all(...params).forEach((row) => {
    const { targets, ...c } = campaignsService.getById(row.id);
    const entry = { ...c, company_name: row.company_name, reason: null };
    if (c.start_date > today) {
      entry.reason = `Starts on ${c.start_date}`;
    } else if (!inTimeWindow(c.time_start, c.time_end, nowHM)) {
      entry.reason = `Outside its daily time window (${c.time_start}-${c.time_end})`;
    }
    (entry.reason ? waiting : playing).push(entry);
  });

  const byPriority = (a, b) => b.priority - a.priority;
  return {
    display: { id: display.id, name: display.name, location: display.location },
    serverTime: now.toISOString(),
    playing: playing.sort(byPriority),
    waiting: waiting.sort(byPriority),
  };
}

module.exports = { listAll, listBrowsable, listForClient, getById, create, assignClient, getPlayingNow };
