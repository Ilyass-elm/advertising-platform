const express = require('express');
const controller = require('./displays.controller');
const { authenticateUser } = require('../auth/auth.middleware');
const { requireStaff, requireClient } = require('../../common/permissions');
const asyncHandler = require('../../common/asyncHandler');

const router = express.Router();
router.use(authenticateUser);

router.get('/mine', requireClient, asyncHandler(controller.myDisplays));   // "basic info about their displays"
router.get('/browse', asyncHandler(controller.browsable));                 // any role: all displays + locations, for campaign targeting
router.get('/', requireStaff, asyncHandler(controller.allDisplays));       // "manage displays"
router.get('/:id', requireStaff, asyncHandler(controller.get));
router.get('/:id/now', asyncHandler(controller.now));                    // what's running on this display (client: own campaigns only)
router.post('/', requireStaff, asyncHandler(controller.create));           // admin adds a display - that's it
router.patch('/:id/assign', requireStaff, asyncHandler(controller.assign)); // "assign displays to clients"

module.exports = router;
