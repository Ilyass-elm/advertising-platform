const express = require('express');
const controller = require('./auth.controller');
const { authenticateUser } = require('./auth.middleware');
const asyncHandler = require('../../common/asyncHandler');

const router = express.Router();

router.post('/login', asyncHandler(controller.login));
router.post('/register-client', asyncHandler(controller.registerClient));
router.get('/me', authenticateUser, asyncHandler(controller.me));

module.exports = router;
