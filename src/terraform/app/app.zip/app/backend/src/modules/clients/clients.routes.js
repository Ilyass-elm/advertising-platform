const express = require('express');
const controller = require('./clients.controller');
const { authenticateUser } = require('../auth/auth.middleware');
const { requireStaff, requireClient } = require('../../common/permissions');
const asyncHandler = require('../../common/asyncHandler');

const router = express.Router();
router.use(authenticateUser);

router.get('/me', requireClient, asyncHandler(controller.me));            // client: own profile
router.get('/', requireStaff, asyncHandler(controller.list));             // staff: "view all clients"
router.get('/:id', requireStaff, asyncHandler(controller.get));
router.patch('/:id', requireStaff, asyncHandler(controller.update));

module.exports = router;
