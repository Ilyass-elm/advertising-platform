const service = require('./displayGroups.service');
const { createGroupSchema, membersSchema } = require('./displayGroups.validation');
const { ok } = require('../../common/apiResponse');

function list(req, res) { ok(res, service.listAll()); }
function get(req, res) { ok(res, service.getById(req.params.id)); }
function create(req, res) {
  const input = createGroupSchema.parse(req.body);
  ok(res, service.create(input), 201);
}
function addMembers(req, res) {
  const { displayIds } = membersSchema.parse(req.body);
  ok(res, service.addMembers(req.params.id, displayIds));
}
function removeMember(req, res) {
  ok(res, service.removeMember(req.params.id, req.params.displayId));
}

module.exports = { list, get, create, addMembers, removeMember };
