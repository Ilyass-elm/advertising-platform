const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuid } = require('uuid');
const db = require('../../config/db');
const env = require('../../config/env');
const { UnauthorizedError, ValidationError } = require('../../common/errors');

function signToken(user) {
  return jwt.sign(
    { sub: user.id, role: user.role, email: user.email, fullName: user.full_name },
    env.jwtSecret,
    { expiresIn: env.jwtExpiresIn }
  );
}

function login({ email, password }) {
  const user = db.prepare('SELECT * FROM users WHERE email = ? AND is_active = 1').get(email);
  if (!user) throw new UnauthorizedError('Invalid credentials');

  const valid = bcrypt.compareSync(password, user.password_hash);
  if (!valid) throw new UnauthorizedError('Invalid credentials');

  return { token: signToken(user), user: publicUser(user) };
}

// Self-service registration is only exposed for the 'client' role;
// admin/employee accounts are created by an existing admin (see users module).
function registerClient({ email, password, fullName, companyName, contactPhone }) {
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existing) throw new ValidationError('Email already registered');

  const userId = uuid();
  const passwordHash = bcrypt.hashSync(password, 10);

  const tx = db.transaction(() => {
    db.prepare(
      `INSERT INTO users (id, email, password_hash, role, full_name) VALUES (?, ?, ?, 'client', ?)`
    ).run(userId, email, passwordHash, fullName);

    db.prepare(
      `INSERT INTO clients (id, user_id, company_name, contact_phone) VALUES (?, ?, ?, ?)`
    ).run(uuid(), userId, companyName, contactPhone || null);
  });
  tx();

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
  return { token: signToken(user), user: publicUser(user) };
}

function publicUser(user) {
  return { id: user.id, email: user.email, role: user.role, fullName: user.full_name };
}

module.exports = { login, registerClient, signToken, publicUser };
