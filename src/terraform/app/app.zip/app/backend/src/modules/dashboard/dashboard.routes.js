const express = require('express');
const controller = require('./dashboard.controller');
const { authenticateUser } = require('../auth/auth.middleware');
const asyncHandler = require('../../common/asyncHandler');

const router = express.Router();
router.get('/', authenticateUser, asyncHandler(controller.get)); // one endpoint, response shaped by req.user.role

module.exports = router;
