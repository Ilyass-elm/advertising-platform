const { z } = require('zod');

const targetSchema = z.object({
  type: z.enum(['display', 'group']),
  id: z.string(),
});

// Order in this array IS the play order - the service writes sequence_order
// from each item's array index, so the client just reorders the array
// client-side (drag/up/down) and resubmits the whole list.
const itemSchema = z.object({
  advertisementId: z.string(),
  durationSeconds: z.coerce.number().int().min(1).max(600).default(10),
});

const createCampaignSchema = z.object({
  name: z.string().min(2),
  startDate: z.string(), // ISO date, e.g. "2026-10-01"
  endDate: z.string(),
  timeStart: z.string().default('00:00'),
  timeEnd: z.string().default('23:59'),
  priority: z.coerce.number().int().min(1).max(10).default(5),
  targets: z.array(targetSchema).min(1),
  items: z.array(itemSchema).min(1),
});

const updateCampaignSchema = createCampaignSchema.partial();

const reviewSchema = z.object({
  decision: z.enum(['approved', 'rejected']),
  rejectionReason: z.string().optional(),
});

module.exports = { createCampaignSchema, updateCampaignSchema, reviewSchema };
