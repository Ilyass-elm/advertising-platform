const express = require('express');
const controller = require('./advertisements.controller');
const { authenticateUser } = require('../auth/auth.middleware');
const { requireStaff, requireClient } = require('../../common/permissions');
const asyncHandler = require('../../common/asyncHandler');
const { upload } = require('./advertisements.upload');

const router = express.Router();
router.use(authenticateUser);

router.get('/mine', requireClient, asyncHandler(controller.myAds));
router.get('/', requireStaff, asyncHandler(controller.allAds));
router.post('/', requireClient, upload.single('file'), asyncHandler(controller.upload));
router.get('/:id/file', asyncHandler(controller.serveFile)); // ownership checked inside

module.exports = router;
