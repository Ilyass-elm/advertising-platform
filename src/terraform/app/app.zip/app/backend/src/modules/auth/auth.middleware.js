const jwt = require('jsonwebtoken');
const env = require('../../config/env');
const { UnauthorizedError } = require('../../common/errors');

// Authenticates a human user (client / employee / admin) via "Authorization: Bearer <jwt>".
function authenticateUser(req, res, next) {
  const header = req.headers.authorization || '';
  const [scheme, token] = header.split(' ');
  if (scheme !== 'Bearer' || !token) return next(new UnauthorizedError('Missing bearer token'));

  try {
    const payload = jwt.verify(token, env.jwtSecret);
    req.user = { id: payload.sub, role: payload.role, email: payload.email, fullName: payload.fullName };
    next();
  } catch (e) {
    next(new UnauthorizedError('Invalid or expired token'));
  }
}

module.exports = { authenticateUser };
