const { z } = require('zod');

const createAdSchema = z.object({
  title: z.string().min(2),
});

module.exports = { createAdSchema };
