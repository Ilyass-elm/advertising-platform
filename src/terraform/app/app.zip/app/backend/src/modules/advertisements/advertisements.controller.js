const service = require('./advertisements.service');
const { createAdSchema } = require('./advertisements.validation');
const { ok } = require('../../common/apiResponse');
const { ValidationError, NotFoundError } = require('../../common/errors');
const storage = require('../../common/storage');
const clientsService = require('../clients/clients.service');

function myAds(req, res) {
  const client = clientsService.getByUserId(req.user.id);
  ok(res, service.listForClient(client.id));
}

function allAds(req, res) {
  ok(res, service.listAll());
}

async function upload(req, res) {
  if (!req.file) throw new ValidationError('No file uploaded (field name: "file")');
  const input = createAdSchema.parse(req.body);
  const client = clientsService.getByUserId(req.user.id);
  const ad = await service.create({ clientId: client.id, ...input, file: req.file });
  ok(res, ad, 201);
}

// Streams (local) or redirects to a signed URL (S3) - either way the client
// only ever sees GET /advertisements/:id/file, never which driver is active.
async function serveFile(req, res) {
  const ad = service.getById(req.params.id);
  if (req.user.role === 'client') {
    const client = clientsService.getByUserId(req.user.id);
    service.assertOwnedByClient(ad.id, client.id);
  }

  const resolved = await storage.resolveForServing(ad);
  if (resolved.kind === 'redirect') return res.redirect(resolved.url);
  if (!resolved.exists) throw new NotFoundError('Content file missing on server');
  res.sendFile(resolved.filePath);
}

module.exports = { myAds, allAds, upload, serveFile };
