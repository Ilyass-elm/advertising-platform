const authService = require('./auth.service');
const { loginSchema, registerClientSchema } = require('./auth.validation');
const { ok } = require('../../common/apiResponse');

function login(req, res) {
  const input = loginSchema.parse(req.body);
  const result = authService.login(input);
  ok(res, result);
}

function registerClient(req, res) {
  const input = registerClientSchema.parse(req.body);
  const result = authService.registerClient(input);
  ok(res, result, 201);
}

function me(req, res) {
  ok(res, req.user);
}

module.exports = { login, registerClient, me };
