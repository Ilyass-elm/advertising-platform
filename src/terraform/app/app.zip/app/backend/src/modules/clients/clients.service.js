const db = require('../../config/db');
const { NotFoundError } = require('../../common/errors');

function list() {
  return db.prepare(
    `SELECT c.id, c.company_name, c.contact_phone, u.email, u.full_name, u.is_active, c.created_at
     FROM clients c JOIN users u ON u.id = c.user_id
     ORDER BY c.created_at DESC`
  ).all();
}

function getById(id) {
  const client = db.prepare(
    `SELECT c.*, u.email, u.full_name, u.is_active
     FROM clients c JOIN users u ON u.id = c.user_id WHERE c.id = ?`
  ).get(id);
  if (!client) throw new NotFoundError('Client not found');
  return client;
}

// Resolve a client row from the logged-in user id (used to scope a client's own data).
function getByUserId(userId) {
  const client = db.prepare('SELECT * FROM clients WHERE user_id = ?').get(userId);
  if (!client) throw new NotFoundError('Client profile not found for this user');
  return client;
}

function update(id, { companyName, contactPhone, notes }) {
  const client = getById(id);
  db.prepare('UPDATE clients SET company_name = ?, contact_phone = ?, notes = ? WHERE id = ?')
    .run(companyName ?? client.company_name, contactPhone ?? client.contact_phone, notes ?? client.notes, id);
  return getById(id);
}

module.exports = { list, getById, getByUserId, update };
