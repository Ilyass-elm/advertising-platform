const { v4: uuid } = require('uuid');
const db = require('../../config/db');
const { NotFoundError } = require('../../common/errors');

function membersFor(groupId) {
  return db.prepare(
    `SELECT d.* FROM display_group_members m JOIN displays d ON d.id = m.display_id WHERE m.group_id = ?`
  ).all(groupId);
}

// Includes each group's members so the shape matches getById() exactly -
// the frontend list view renders member counts/names without a second call.
function listAll() {
  const groups = db.prepare('SELECT * FROM display_groups ORDER BY created_at DESC').all();
  return groups.map((g) => ({ ...g, members: membersFor(g.id) }));
}

function getById(id) {
  const group = db.prepare('SELECT * FROM display_groups WHERE id = ?').get(id);
  if (!group) throw new NotFoundError('Display group not found');
  return { ...group, members: membersFor(id) };
}

function create({ name, description, clientId }) {
  const id = uuid();
  db.prepare('INSERT INTO display_groups (id, name, description, client_id) VALUES (?, ?, ?, ?)')
    .run(id, name, description || null, clientId || null);
  return getById(id);
}

function addMembers(groupId, displayIds) {
  getById(groupId);
  const stmt = db.prepare('INSERT OR IGNORE INTO display_group_members (group_id, display_id) VALUES (?, ?)');
  const tx = db.transaction((ids) => ids.forEach((did) => stmt.run(groupId, did)));
  tx(displayIds);
  return getById(groupId);
}

function removeMember(groupId, displayId) {
  db.prepare('DELETE FROM display_group_members WHERE group_id = ? AND display_id = ?').run(groupId, displayId);
  return getById(groupId);
}

// Resolves a display group to its member display ids - used by scheduling
// so a campaign targeting a group re-resolves membership on every schedule pull.
function resolveDisplayIds(groupId) {
  return db.prepare('SELECT display_id FROM display_group_members WHERE group_id = ?')
    .all(groupId).map((r) => r.display_id);
}

module.exports = { listAll, getById, create, addMembers, removeMember, resolveDisplayIds };
