const service = require('./displays.service');
const { createDisplaySchema, assignSchema } = require('./displays.validation');
const { ok } = require('../../common/apiResponse');
const clientsService = require('../clients/clients.service');

function allDisplays(req, res) {
  ok(res, service.listAll());
}

// Any authenticated user (client or staff) - "see all displays and their
// locations to decide where to host the ad".
function browsable(req, res) {
  ok(res, service.listBrowsable());
}

function myDisplays(req, res) {
  const client = clientsService.getByUserId(req.user.id);
  ok(res, service.listForClient(client.id));
}

function get(req, res) {
  ok(res, service.getById(req.params.id));
}

function create(req, res) {
  const input = createDisplaySchema.parse(req.body);
  ok(res, service.create(input), 201);
}

function assign(req, res) {
  const { clientId } = assignSchema.parse(req.body);
  ok(res, service.assignClient(req.params.id, clientId));
}

// Any role. Staff see every campaign on the display; a client only sees their own.
function now(req, res) {
  let onlyClientId;
  if (req.user.role === 'client') {
    onlyClientId = clientsService.getByUserId(req.user.id).id;
  }
  ok(res, service.getPlayingNow(req.params.id, { onlyClientId }));
}

module.exports = { allDisplays, myDisplays, get, create, assign, browsable, now };
