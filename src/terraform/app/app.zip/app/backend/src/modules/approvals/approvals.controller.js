const service = require('./approvals.service');
const { reviewSchema } = require('../campaigns/campaigns.validation');
const { ok } = require('../../common/apiResponse');

function queue(req, res) {
  ok(res, service.pendingQueue());
}

function review(req, res) {
  const input = reviewSchema.parse(req.body);
  ok(res, service.review(req.params.campaignId, req.user.id, input));
}

module.exports = { queue, review };
