const service = require('./clients.service');
const { updateClientSchema } = require('./clients.validation');
const { ok } = require('../../common/apiResponse');

function list(req, res) {
  ok(res, service.list());
}

function get(req, res) {
  ok(res, service.getById(req.params.id));
}

function me(req, res) {
  ok(res, service.getByUserId(req.user.id));
}

function update(req, res) {
  const input = updateClientSchema.parse(req.body);
  ok(res, service.update(req.params.id, input));
}

module.exports = { list, get, me, update };
