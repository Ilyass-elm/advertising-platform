const express = require('express');
const controller = require('./displayGroups.controller');
const { authenticateUser } = require('../auth/auth.middleware');
const { requireStaff } = require('../../common/permissions');
const asyncHandler = require('../../common/asyncHandler');

const router = express.Router();
router.use(authenticateUser, requireStaff); // group management is a staff feature

router.get('/', asyncHandler(controller.list));
router.get('/:id', asyncHandler(controller.get));
router.post('/', asyncHandler(controller.create));
router.post('/:id/members', asyncHandler(controller.addMembers));
router.delete('/:id/members/:displayId', asyncHandler(controller.removeMember));

module.exports = router;
