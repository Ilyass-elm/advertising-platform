const { z } = require('zod');

const createGroupSchema = z.object({
  name: z.string().min(2),
  description: z.string().optional(),
  clientId: z.string().optional(),
});

const membersSchema = z.object({ displayIds: z.array(z.string()).min(1) });

module.exports = { createGroupSchema, membersSchema };
