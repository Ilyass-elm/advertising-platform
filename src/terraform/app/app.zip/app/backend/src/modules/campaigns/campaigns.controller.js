const service = require('./campaigns.service');
const { createCampaignSchema, updateCampaignSchema } = require('./campaigns.validation');
const { ok } = require('../../common/apiResponse');
const { ForbiddenError } = require('../../common/errors');
const clientsService = require('../clients/clients.service');

function myCampaigns(req, res) {
  const client = clientsService.getByUserId(req.user.id);
  ok(res, service.listForClient(client.id));
}

function allCampaigns(req, res) {
  ok(res, service.listAll({ status: req.query.status }));
}

// Detail view - "client clicks on it and sees the item(s)". Staff can view
// any campaign; a client may only view their own.
function get(req, res) {
  const campaign = service.getById(req.params.id);
  if (req.user.role === 'client') {
    const client = clientsService.getByUserId(req.user.id);
    if (campaign.client_id !== client.id) throw new ForbiddenError('Not your campaign');
  }
  ok(res, campaign);
}

function create(req, res) {
  const input = createCampaignSchema.parse(req.body);
  const client = clientsService.getByUserId(req.user.id);
  ok(res, service.create(client.id, input), 201);
}

function update(req, res) {
  const input = updateCampaignSchema.parse(req.body);
  const client = clientsService.getByUserId(req.user.id);
  ok(res, service.update(req.params.id, client.id, input));
}

function stop(req, res) {
  if (req.user.role === 'client') {
    const client = clientsService.getByUserId(req.user.id);
    service.assertOwnedByClient(req.params.id, client.id);
  }
  ok(res, service.setStatus(req.params.id, 'stopped', req.user.id));
}

module.exports = { myCampaigns, allCampaigns, get, create, update, stop };
