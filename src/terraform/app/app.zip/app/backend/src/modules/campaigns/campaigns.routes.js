const express = require('express');
const controller = require('./campaigns.controller');
const { authenticateUser } = require('../auth/auth.middleware');
const { requireStaff, requireClient } = require('../../common/permissions');
const asyncHandler = require('../../common/asyncHandler');

const router = express.Router();
router.use(authenticateUser);

router.get('/mine', requireClient, asyncHandler(controller.myCampaigns));  // "view their campaigns", status incl.
router.post('/', requireClient, asyncHandler(controller.create));          // "create and edit campaigns"
router.patch('/:id', requireClient, asyncHandler(controller.update));

router.get('/', requireStaff, asyncHandler(controller.allCampaigns));      // "view all campaigns", ?status= filter
router.get('/:id', asyncHandler(controller.get));                          // staff or owning client (service checks ownership on write paths)
router.post('/:id/stop', asyncHandler(controller.stop));                   // client (own only) or staff (any)

module.exports = router;
